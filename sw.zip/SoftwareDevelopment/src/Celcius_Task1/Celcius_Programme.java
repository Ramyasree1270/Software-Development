package Celcius_Task1;

import java.util.Scanner;

public class Celcius_Programme {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the temperature value: ");
        double temperature = scanner.nextDouble();

        System.out.print("Enter the unit (C for Celsius, F for Fahrenheit, K for Kelvin): ");
        char unit = scanner.next().toUpperCase().charAt(0);

        switch(unit) {
            case 'C':
                double toF = (temperature * 9/5) + 32;
                double toK = temperature + 273.15;
                System.out.println("Fahrenheit: " + toF);
                System.out.println("Kelvin: " + toK);
                break;

            case 'F':
                double toC = (temperature - 32) * 5/9;
                double toK2 = toC + 273.15;
                System.out.println("Celsius: " + toC);
                System.out.println("Kelvin: " + toK2);
                break;

                
               
            case 'K':
                double toC2 = temperature - 273.15;
                double toF2 = (toC2 * 9/5) + 32;
                System.out.println("Celsius: " + toC2);
                System.out.println("Fahrenheit: " + toF2);
                break;

            default:
                System.out.println("Invalid unit entered. Please enter C, F, or K.");
        }

        scanner.close();
    }
}
