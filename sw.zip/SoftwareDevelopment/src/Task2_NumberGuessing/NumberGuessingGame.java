
package Task2_NumberGuessing;
import java.util.Random;
import java.util.Scanner;
 public class NumberGuessingGame {
		    public static void main(String[] args) {
		        Random random = new Random();
		        int targetNumber = random.nextInt(100) + 1; // Generates number between 1 and 100

		        Scanner scanner = new Scanner(System.in);
		        int guess;
		        int attempts = 0;

		        System.out.println("Guess the number between 1 and 100:");

		        while (true) {
		            System.out.print("Enter your guess: ");
		            guess = scanner.nextInt();
		            attempts++;

		            if (guess < targetNumber) {
		                System.out.println("Too low! Try again.");
		            } else if (guess > targetNumber) {
		                System.out.println("Too high! Try again.");
		            } else {
		                System.out.println("Correct! You've guessed the number.");
		                System.out.println("It took you " + attempts + " attempts.");
		                break;
		            }
		        }

		        scanner.close();
		    }
		


	}


